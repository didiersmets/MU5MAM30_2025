filetype plugin indent on
syntax on

set shortmess=a
set cmdheight=2
set syntax=on

set background=light
set laststatus=2 

set textwidth=80
set nowrap
set autowrite

set shiftwidth=8 
set tabstop=8 
set softtabstop=8 
set noexpandtab 
set autoindent 
set smartindent
set number
set relativenumber

set nolist
set listchars=tab:-->,eol:$,trail:.

set incsearch

" gui
set guifont=MonoSpace\ Regular\ 12
"set guioptions -=T
autocmd FileType cpp,c,cxx,h,hpp,python,sh  setlocal colorcolumn=80

" colorscheme
let g:github_colors_soft = 1
colorscheme github
let g:lightline = { 'colorscheme': 'github' }

" edited line color change in edit mode
:autocmd InsertEnter * set cul
:autocmd InsertLeave * set nocul

" cursor depend on mode
let &t_SI = "\e[6 q"
let &t_EI = "\e[2 q"

" reset cursor on start:
augroup myCmds
au!
autocmd VimEnter * silent !echo -ne "\e[2 q"
augroup END

" vimtex
let g:vimtex_view_method = 'zathura'
let g:vimtex_format_enabled = 1

" youcompleteme
let g:ycm_auto_trigger = 0
let g:ycm_autoclose_preview_window_after_completion = 1
let g:ycm_key_list_stop_completion = ['<c-y>']

" clang-format
let g:clang_format#detect_style_file = 1
let g:clang_format#auto_format = 1

" map to <Leader>cf in C++ code
autocmd FileType c,cpp,objc nnoremap <buffer><Leader>cf :<C-u>ClangFormat<CR>
autocmd FileType c,cpp,objc vnoremap <buffer><Leader>cf :ClangFormat<CR>
" if you install vim-operator-user
"autocmd FileType c,cpp,objc map <buffer><Leader>x <Plug>(operator-clang-format)
" Toggle auto formatting:
"nmap <Leader>C :ClangFormatAutoToggle<CR>
